import initEfectDom from '/scripts/efeitos-dom.js';

initEfectDom();